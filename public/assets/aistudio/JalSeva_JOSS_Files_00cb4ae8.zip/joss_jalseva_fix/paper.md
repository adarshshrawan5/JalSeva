---
title: 'JalSeva: A Digital Water Supply Management Portal for Mira–Bhayandar Citizens'
authors:
  - name: Adarsh Yadav
    affiliation: "1"
    orcid: 0009-0008-1266-6869
affiliations:
  - name: Department of Information Technology, Shree L. R. Tiwari College of Engineering, Mira-Bhayandar, Maharashtra, India
    index: 1
tags:
  - civic technology
  - water supply
  - grievance redressal
  - software engineering
  - web application
date: 27 October 2026
bibliography: paper.bib
---

## Summary

JalSeva is an open-source web application prototype that brings several urban water-service workflows into one interface: ward-level supply schedules, citizen grievances, emergency tanker requests, delivery handover verification, field-worker assignments, and administrative notices. It was developed as an academic software-engineering prototype using React and TypeScript, with Firebase Authentication and Cloud Firestore for authentication and cloud persistence. Browser `localStorage` provides an immediate local cache, while the application tracks whether cloud writes succeed or fail. The repository also contains declarative Firestore security rules and a headless automated test runner.

JalSeva is not an official municipal application. It has not been commissioned, endorsed, or deployed by the Mira–Bhayandar Municipal Corporation (MBMC), and it does not connect to municipal servers or physical sensors. Fleet movement, reservoir and pressure telemetry, citizen notifications, and payment receipts are demonstrative simulations rather than live integrations. A related academic project report is available on Zenodo [@yadav2026jalseva].

## Statement of Need

In places where drinking water is supplied intermittently, residents may need to find changing schedules, report service problems, and request emergency delivery through disconnected channels. Municipal operations also involve different responsibilities for citizens, dispatch staff, field workers, and administrators. JalSeva provides a single prototype in which these roles and workflows can be explored together. Its intended users are software-engineering students, researchers studying civic technology, and developers who want a documented example of role-based workflows, cloud synchronization, and location-aware service requests.

The software models a grievance lifecycle (`Pending`, `Assigned`, `In Progress`, `Resolved`, and `Reopened`), validation for tanker bookings, nearest-depot selection using the Haversine distance formula, and a PIN-verified delivery handover. Its local/cloud persistence design exposes cloud-write failures rather than silently presenting every local change as synchronized. These features make the repository useful as a teaching and prototyping artifact, but the present work does not establish improvements in real municipal response times, water availability, or citizen satisfaction.

## State of the Field

Open311 GeoReport defines an API model for reporting and tracking location-based civic service requests and can support integration between third-party applications and participating jurisdictions [@open311georeport]. FixMyStreet is an established open-source geographic reporting platform that routes reports about public-space problems to relevant authorities and can use Open311-compatible services [@fixmystreetplatform]. These systems demonstrate that civic reporting is an existing software domain; JalSeva should not be interpreted as replacing them or as introducing a new general-purpose civic reporting standard.

JalSeva's narrower contribution is a single academic prototype focused on intermittent water-supply schedules and related workflows such as tanker booking, delivery PIN checks, worker assignment, and the distinction between local state and successful cloud synchronization. No systematic feature benchmark or comparative user study has yet been conducted. The project therefore presents a case-specific implementation for inspection and further evaluation, rather than a claim that a new standalone platform is superior to established systems. Future work should compare whether adapting an existing civic-reporting platform or integrating a standard such as Open311 would be more suitable for a production deployment.

## Software Design

The client is implemented with React and TypeScript. Its storage layer writes user actions to `localStorage` for immediate interface updates and attempts asynchronous persistence to Cloud Firestore. The interface records synchronization state so that failed cloud operations can be shown to the user. Firebase Authentication supplies sign-in, while Firestore security rules are intended to enforce role- and document-level access restrictions. The repository's documented workflows include complaint tracking, tanker dispatch, delivery PIN validation, worker job claiming and reassignment, and administrator-managed supply notices.

These choices trade a low-latency local interaction model against the complexity of reconciling state across browsers and cloud storage. The current prototype uses an append/latest-style synchronization approach rather than a conflict-free replicated data type or vector-clock protocol, so multi-device conflict resolution remains limited. The test runner described in the README includes 19 cases for workflow transitions, duplicate booking prevention, synchronization success and failure paths, hydration deduplication, and selected access-control checks. Authors and reviewers should execute the tests in the target environment; these documented test results are not a substitute for production load, security, or privacy testing.

## Research Impact Statement

At the time of submission, JalSeva is documented as a student-developed prototype with a public source repository, a demonstration website, and a related Zenodo report [@yadav2026jalseva]. The project documentation describes automated functional tests, but no independent municipal deployment, external research-group adoption, published evaluation of outcomes, or controlled benchmark has been established in this manuscript. Accordingly, realized external research impact is not claimed. The near-term research value is the availability of a reproducible implementation and testable workflows for further study; its significance would need to be demonstrated through independent reuse, comparative evaluation, and documented feedback from researchers or practitioners.

## AI Usage Disclosure

The repository identifies a Google Gemini/AI Studio repository template as its starting point; the exact Gemini model/version used in project development is not recorded in the repository metadata. ChatGPT (GPT-6) assisted with drafting this manuscript and submission-support documentation. Before treating this manuscript as final, the submitting author must review and edit all AI-assisted text, verify factual statements and references against the code and records, validate the reported tests, and confirm that the substantive design decisions are their own. Any additional AI tools or use in implementation should be added to this disclosure accurately.

## Acknowledgements

The project is documented as an academic software-engineering prototype associated with Shree L. R. Tiwari College of Engineering. No external financial support is identified in the current project documentation; the author should update this statement if funding or material support was received.

## Availability

Source code: https://github.com/adarshshrawan5/JalSeva

Demonstration: https://jal-seva-seven.vercel.app/

Related project report: https://doi.org/10.5281/zenodo.23645173

License: Apache-2.0.
